import importlib.util,json,pathlib,tempfile,unittest
ROOT=pathlib.Path(__file__).resolve().parents[1]
def module(name, rel):
    spec=importlib.util.spec_from_file_location(name,ROOT/rel)
    m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m);return m
builder=module('build_catalog','tools/build_catalog.py')
validator=module('validate_catalog','tools/validate_catalog.py')
class CatalogContractTest(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        builder.main()
        cls.data=json.loads((ROOT/'data/catalog_review_v1.json').read_text())
    def test_schema_and_invariants(self): self.assertEqual(validator.validate(),[])
    def test_no_publication_or_operational_links(self):
        for r in self.data['records']:
            self.assertEqual(r['publication']['state'],'draft')
            self.assertIsNone(r['operational_link']['place_id'])
            self.assertIsNone(r['operational_link']['capacity_total'])
            self.assertFalse(r['operational_link']['operational_approved'])
            self.assertFalse(any(m['publish_approved'] for m in r['media_candidates']))
    def test_counts(self):
        a=self.data['records'];self.assertEqual(len(a),80)
        self.assertEqual(len([x for x in a if x['map_reference']['number']]),62)
        self.assertEqual(len([x for x in a if not x['map_reference']['number']]),18)
        self.assertEqual(len({x['external_key'] for x in a}),80)
        self.assertEqual(len([x for x in a if x['municipality']['name'] is None]),40)
    def test_generic_media_subject_risk(self):
        check={r['canonical_name']:r for r in self.data['records']}
        for name in ['Lagoa do Japonês','Cânion Encantado','Fervedouro Buritizinho']:
            self.assertIn('media_subject_mismatch_risk',check[name]['quality_warnings'])
    def test_source_integrity_detects_changes(self):
        bad=dict(self.data);bad['source_sha256']='0'*64
        with tempfile.NamedTemporaryFile(mode='w',suffix='.json',encoding='utf-8') as f:
            json.dump(bad,f);f.flush();self.assertTrue(validator.validate(f.name))
if __name__=='__main__':unittest.main()
