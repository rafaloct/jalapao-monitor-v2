import json,pathlib,subprocess,sys,tempfile,unittest
ROOT=pathlib.Path(__file__).resolve().parents[1]
class ReconciliationTests(unittest.TestCase):
    def test_matching_place_is_never_auto_linked(self):
        with tempfile.TemporaryDirectory() as d:
            d=pathlib.Path(d);existing=d/'existing.json';report=d/'report.json'
            existing.write_text(json.dumps({'items':[{'id':'fake-pb-1','name':'Cachoeira do Formiga','status':'active'}]}),encoding='utf-8')
            p=subprocess.run([sys.executable,str(ROOT/'tools/reconcile_places_preview.py'),'--existing-places',str(existing),'--output',str(report)],capture_output=True,text=True)
            self.assertEqual(p.returncode,0,p.stderr)
            x=json.loads(report.read_text(encoding='utf-8'))
            self.assertGreaterEqual(x['name_match_candidates'],1)
            self.assertEqual(x['proposed_auto_links'],0)
            self.assertEqual(x['proposed_auto_creates'],0)
            self.assertTrue(any(z['decision']=='manual_review_required' for z in x['records']))
            self.assertTrue(all(not z['link_automatically'] for z in x['records']))
    def test_no_apply_flag_supported(self):
        p=subprocess.run([sys.executable,str(ROOT/'tools/reconcile_places_preview.py'),'--apply'],capture_output=True,text=True)
        self.assertNotEqual(p.returncode,0)
if __name__=='__main__':unittest.main()
