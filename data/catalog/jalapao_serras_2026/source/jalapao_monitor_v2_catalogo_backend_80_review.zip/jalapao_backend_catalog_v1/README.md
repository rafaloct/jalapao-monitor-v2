# Catálogo editorial Jalapão + Serras Gerais para Jalapão Monitor V2

**Entrega de dados para avaliação técnica, não é importação nem deploy.** Base auditada: `main` em `66f62e1b8e96009a44cf1a6fb38052d0801153a1` (2026-10-13). Repositório: https://github.com/rafaloct/jalapao-monitor-v2

## Conteúdo

- `source/original_80_review_2026-10-13.json`: instantâneo imutável da versão fornecida na conversa.
- `data/catalog_review_v1.json`: envelope com 80 atrativos, status **draft**, identificador externo estável, fontes, mídia e campos nulos sem evidência.
- `data/catalog_review_v1.jsonl`: um registro por linha para pipelines ETL server-side.
- `data/editorial_review_queue.csv`: fila de verificação municipal, mídia e fontes.
- `schemas/tourism_catalog_review_v1.schema.json`: contrato JSON Schema 2020-12.
- `tools/build_catalog.py`, `tools/validate_catalog.py`, `tools/reconcile_places_preview.py`: geração, validação e proposta read-only de conciliação com cadastro operacional exportado.
- `reports/preflight.json`, `reports/operational_linkage_preview.json`: indicadores e evidências locais.
- `docs/BACKEND_INTEGRATION.md`: mapeamento do schema PocketBase existente, arquitetura sugerida e gates.

## Resultado de preflight

**80 candidatos**, **62 no mapa**, **18 extras**, **40 municípios sem confirmação**, **80 sem coordenada verificada**, **16 mídias Wikimedia com licença declarada mas ainda não liberadas**, **5 galerias institucionais sujeitas a licença**, **0 itens publicados**, **0 lugares operacionais criados**, **0 chamadas de servidor**.

Os 80 pontos não são necessariamente 80 locais turísticos distintos/visitáveis: possíveis homônimos e alias devem ser verificados. Os 40 municípios preenchidos no material original também carecem de revalidação de evidência. O catálogo deriva de um mapa promocional e pesquisas documentais heterogêneas, não de um censo completo.

## Comandos

Requer Python 3.10+ e `jsonschema` para verificação do contrato (nenhum acesso ao banco):

```sh
python -m pip install jsonschema
python tools/build_catalog.py
python tools/validate_catalog.py
python tools/reconcile_places_preview.py
python -m unittest discover -s tests -v
```

O arquivo gerado é **dataset de staging editorial**, não um fixture diretamente importável em `places` (a collection atual exige latitude, longitude, capacidade e dono). Não produzir estes valores sinteticamente. Não executar contra produção, não importar para `visits` ou `place_visits`. Até aprovação da ADR #2, qualquer collection editorial sugerida é apenas proposta.
