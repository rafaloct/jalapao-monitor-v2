#!/usr/bin/env python3
"""Offline read-only name-matching proposal against an exported PocketBase places list.
NEVER creates/updates records. No server connection. Match results are manual-only.
"""
import argparse,json,pathlib,re,unicodedata,collections
ROOT=pathlib.Path(__file__).resolve().parents[1]

def normalize(value):
    value=''.join(c for c in unicodedata.normalize('NFKD',value.casefold()) if not unicodedata.combining(c))
    return re.sub(r'\s+',' ',re.sub(r'[^a-z0-9]+',' ',value)).strip()

def main():
    p=argparse.ArgumentParser(description='Offline/manual review preview, NO writes')
    p.add_argument('--existing-places',type=pathlib.Path,help='Sanitized JSON export from PB places: array or {items:[...]}')
    p.add_argument('--output',type=pathlib.Path,default=ROOT/'reports/operational_linkage_preview.json')
    args=p.parse_args()
    catalog=json.loads((ROOT/'data/catalog_review_v1.json').read_text(encoding='utf-8'))['records']
    places=[]
    if args.existing_places:
        data=json.loads(args.existing_places.read_text(encoding='utf-8'))
        places=data['items'] if isinstance(data,dict) and 'items' in data else data
        if not isinstance(places,list):p.error('Expected array or {items: array}')
    lookup=collections.defaultdict(list)
    for z in places:
        if not isinstance(z,dict) or not isinstance(z.get('id'),str) or not isinstance(z.get('name'),str):
            p.error('Every exported place must contain string id and name')
        lookup[normalize(z['name'])].append({'id':z['id'],'name':z['name'],'status':z.get('status')})
    suggestions=[]
    for z in catalog:
        names=[z['canonical_name'],*z['aliases']]
        possibilities={p['id']:p for n in names for p in lookup.get(normalize(n),[])}
        suggestions.append({
            'external_key':z['external_key'], 'display_name':z['canonical_name'],
            'candidate_existing_places':list(possibilities.values()),
            'decision':'manual_review_required' if possibilities else 'no_name_match',
            'link_automatically':False,
            'create_operational_place':False,
            'reason':'Name equality alone does not prove same POI, location, operator, or right to operate'
        })
    preview={'read_only':True,'network_calls':0,'writes':0,'existing_places_in_export':len(places),
             'name_match_candidates':sum(bool(s['candidate_existing_places']) for s in suggestions),
             'proposed_auto_links':0,'proposed_auto_creates':0,'records':suggestions}
    args.output.parent.mkdir(parents=True,exist_ok=True)
    args.output.write_text(json.dumps(preview,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
    print(json.dumps({k:v for k,v in preview.items() if k!='records'},ensure_ascii=False))

if __name__=='__main__':main()
