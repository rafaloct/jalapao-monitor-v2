#!/usr/bin/env python3
"""Fail-closed validation of editorial catalog. Read-only and deterministic."""
import argparse, hashlib, json, pathlib, sys
ROOT=pathlib.Path(__file__).resolve().parents[1]

def validate(path=None):
    path=path or ROOT/'data/catalog_review_v1.json'
    data=json.loads(pathlib.Path(path).read_text(encoding='utf-8'))
    schema=json.loads((ROOT/'schemas/tourism_catalog_review_v1.schema.json').read_text(encoding='utf-8'))
    try:
        from jsonschema import Draft202012Validator
    except ImportError as e:
        raise RuntimeError('Install jsonschema for contract validation (python -m pip install jsonschema)') from e
    errors=[f'{list(e.absolute_path)}: {e.message}' for e in Draft202012Validator(schema).iter_errors(data)]
    source=(ROOT/'source/original_80_review_2026-10-13.json').read_bytes()
    if data.get('source_sha256')!=hashlib.sha256(source).hexdigest():errors.append('Source SHA-256 does not match original snapshot')
    entries=data.get('records') or []
    keys=[e['external_key'] for e in entries]
    if len(keys)!=len(set(keys)):errors.append('Duplicate external_key')
    map_ids=[e['map_reference']['number'] for e in entries if e['map_reference']['number'] is not None]
    if sorted(map_ids)!=list(range(1,63)):errors.append('Map identifiers 1..62 incomplete or duplicated')
    if len(entries)!=80:errors.append(f'Expected 80 consolidated source records, received {len(entries)}')
    for e in entries:
        if not e['canonical_name'].strip():errors.append(f'{e["external_key"]}: blank name')
        if e['geolocation']['latitude'] is not None or e['geolocation']['longitude'] is not None:
            errors.append(f'{e["external_key"]}: geolocation unexpectedly set without evidence approval')
        if e['operational_link']['place_id'] is not None:errors.append('Operational linking is not approved')
        if e['publication']['state']!='draft':errors.append('Premature publication')
        if any(m['publish_approved'] for m in e['media_candidates']):errors.append('Premature media publication')
        if any(m['rights_state']=='permission_required' and m['display_url'] for m in e['media_candidates']):
            errors.append('Institutional gallery image URL not cleared')
    return errors

if __name__=='__main__':
    ap=argparse.ArgumentParser();ap.add_argument('file',nargs='?',type=pathlib.Path);a=ap.parse_args()
    problems=validate(a.file)
    print('PASS: schema + 80 IDs + 62 map IDs + SHA + no operational writes + no premature publication' if not problems else 'FAIL:\n'+'\n'.join(problems))
    sys.exit(1 if problems else 0)
