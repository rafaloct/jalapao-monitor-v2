#!/usr/bin/env python3
"""Build editorial catalog import candidates; NO network and NO database writes."""
import csv, hashlib, json, pathlib, re, unicodedata, collections
ROOT=pathlib.Path(__file__).resolve().parents[1]
SRC=ROOT/'source/original_80_review_2026-10-13.json'
DEST=ROOT/'data'
CATEGORIES={
    'Cachoeira':'cachoeira',
    'Fervedouro':'fervedouro',
    'Formação rochosa / mirante':'formacao_mirante',
    'Formação rochosa':'formacao_mirante',
    'Serra/mirante':'formacao_mirante',
    'Praia fluvial':'praia_fluvial',
    'Turismo comunitário':'turismo_comunitario',
    'Cânion':'canion',
    'Lagoa':'lagoa',
    'Nascente':'nascente',
    'Dunas':'dunas',
    'Trilha':'trilha',
    'Experiência comunitária e gastronômica':'experiencia_comunitaria',
    'Vivência produtiva e cultural':'experiencia_comunitaria',
    'Gruta':'gruta',
    'Rio e balneário':'balneario',
    'Balneário':'balneario',
    'Outros / confirmar categoria':'outros_pendente',
}
# Advisory only: core PocketBase places.type only accepts a small enumerated subset.
OPERATIONAL_TYPE_HINT={'cachoeira':'cachoeira','fervedouro':'fervedouro','turismo_comunitario':'atrativo_cultural','experiencia_comunitaria':'atrativo_cultural'}
GENERIC_MEDIA_MARKERS=['estacao ecologica','parque estadual do jalapao']

def stable_key(source_id):
    if not re.fullmatch(r'[a-z0-9]+(?:-[a-z0-9]+)*',source_id):
        raise ValueError(f'Unsafe source key: {source_id!r}')
    # Immutable source ID, not derived from changing display name after initial import.
    return 'jalapao-inventario-20261013:'+source_id

def make_media(entry):
    photo=entry.get('foto');out=[]
    if isinstance(photo,dict) and photo.get('arquivo_wikimedia'):
        file_title=photo.get('arquivo','')
        deaccent=''.join(c for c in unicodedata.normalize('NFKD', file_title.lower()) if not unicodedata.combining(c))
        name_deaccent=''.join(c for c in unicodedata.normalize('NFKD', entry['nome_canonico'].lower()) if not unicodedata.combining(c))
        generic=any(marker in deaccent for marker in GENERIC_MEDIA_MARKERS) and name_deaccent not in deaccent
        # Even records described as validated in source are review candidates in this package.
        out.append(dict(
            provider='wikimedia_commons',
            source_page=photo.get('arquivo_wikimedia'),
            display_url=photo.get('url'),
            credit=photo.get('autor'),
            license_code=photo.get('licenca'),
            license_url=photo.get('licenca_url'),
            rights_state='license_claim_in_source_needs_recheck',
            location_match_state='not_verified' if generic else 'candidate_needs_manual_confirmation',
            publish_approved=False,
        ))
    if entry.get('imagem_pagina_oficial'):
        out.append(dict(
            provider='institutional_gallery',
            source_page=entry['imagem_pagina_oficial'],
            display_url=None,
            credit=None,
            license_code=None,
            license_url=None,
            rights_state='permission_required',
            location_match_state='needs_manual_confirmation',
            publish_approved=False,
        ))
    return out

def candidate(entry):
    if entry.get('numero_no_mapa') is not None:
        assert isinstance(entry['numero_no_mapa'],int)
    category=CATEGORIES[entry['categoria']]
    media=make_media(entry)
    warnings=[]
    if entry.get('municipio') is None: warnings.append('municipality_unverified')
    if entry.get('latitude') is None or entry.get('longitude') is None:warnings.append('coordinates_missing')
    if not entry.get('fonte_institucional_ou_referencia'):warnings.append('institutional_evidence_missing')
    if not media:warnings.append('media_missing')
    if any(m['location_match_state']=='not_verified' for m in media):warnings.append('media_subject_mismatch_risk')
    if entry.get('equivalencia_com_catalogo_anterior')=='possivel':warnings.append('possible_alias_collision')
    if category=='outros_pendente':warnings.append('category_unverified')
    if entry.get('visita_autorizada') is None:warnings.append('visitation_authorization_unknown')
    original_name=entry.get('nome_no_mapa')
    aliases=sorted({s for s in [original_name] if s and s.strip()!=entry['nome_canonico']})
    return {
      'external_key':stable_key(entry['id']),
      'canonical_name':entry['nome_canonico'],
      'aliases':aliases,
      'classification':{'category_code':category,'category_original':entry['categoria'],
                        'region_hint':entry['setor_do_mapa'],
                        'tourism_region_claim':entry.get('recorte_turistico'),
                        'region_verified':False},
      'municipality':{'name':entry.get('municipio'),'verification':'needs_recheck' if entry.get('municipio') else 'unknown',
                      'original_status':entry.get('municipio_status')},
      'geolocation':{'latitude':entry.get('latitude'),'longitude':entry.get('longitude'),
                     'google_place_id':entry.get('google_place_id'), 'verified':False},
      'publication':{'state':'draft','review':'pending_human_review','visitation_authorized':entry.get('visita_autorizada'),
                     'last_reviewed_at':None},
      'operational_link':{'place_id':None,'operational_type_hint':OPERATIONAL_TYPE_HINT.get(category),
                          'capacity_total':None,'owner_name':None,'operational_approved':False},
      'map_reference':{'source_map':'mapa_jalapao_serras_gerais_user_supplied',
                       'number':entry.get('numero_no_mapa'),'original_name':original_name},
      'sources':{
           'source_catalog_version':'0.2.0-review',
           'source_catalog_id':entry['id'],
           'original_source_description':entry.get('fonte_mapa'),
           'documentary_urls':([entry['fonte_institucional_ou_referencia']] if isinstance(entry.get('fonte_institucional_ou_referencia'),str) else (entry.get('fonte_institucional_ou_referencia') or [])),
           'notes':entry.get('nota_validacao'),
           'source_updated_date':entry.get('data_atualizacao'),
           'source_registration_status':entry.get('status_cadastro'),
           'prior_catalog_match':entry.get('equivalencia_com_catalogo_anterior')},
      'links':{'maps_search_url':entry.get('google_maps_busca'),'image_search_url':entry.get('busca_imagens')},
      'media_candidates':media,
      'quality_warnings':warnings,
    }

def main():
    original=json.loads(SRC.read_text(encoding='utf-8'))
    rows=original['atrativos']
    cands=[candidate(x) for x in rows]
    cands.sort(key=lambda x:(x['map_reference']['number'] is None,x['map_reference']['number'] or 999, x['canonical_name']))
    obj={
       'schema_version':'tourism_catalog_review.v1',
       'source_catalog_version':original.get('versao'),
       'source_date':original.get('data'),
       'source_sha256':hashlib.sha256(SRC.read_bytes()).hexdigest(),
       'intended_backend':'PocketBase; editorial catalog proposed, distinct from operational places',
       'requires_backend_schema_approval':True,
       'import_permission':'PREVIEW_ONLY',
       'auto_publish':False,
       'auto_create_operational_places':False,
       'records':cands,
    }
    DEST.mkdir(parents=True,exist_ok=True)
    (DEST/'catalog_review_v1.json').write_text(json.dumps(obj,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
    with (DEST/'catalog_review_v1.jsonl').open('w',encoding='utf-8') as f:
        for x in cands:f.write(json.dumps(x,ensure_ascii=False,sort_keys=True)+'\n')
    columns=['external_key','canonical_name','category_code','region_hint','municipality','municipality_verified','latitude','longitude','photo_candidates','source_urls','map_number','warnings','publication_state','operational_place_id']
    with (DEST/'editorial_review_queue.csv').open('w',encoding='utf-8-sig',newline='') as f:
        w=csv.DictWriter(f,fieldnames=columns,delimiter=';');w.writeheader()
        for x in cands:
            w.writerow({'external_key':x['external_key'],'canonical_name':x['canonical_name'],
                'category_code':x['classification']['category_code'],'region_hint':x['classification']['region_hint'],
                'municipality':x['municipality']['name'] or '',
                'municipality_verified':x['municipality']['verification'],
                'latitude':x['geolocation']['latitude'] if x['geolocation']['latitude'] is not None else '',
                'longitude':x['geolocation']['longitude'] if x['geolocation']['longitude'] is not None else '',
                'photo_candidates':len(x['media_candidates']),
                'source_urls':' | '.join(x['sources']['documentary_urls'] or []),
                'map_number':x['map_reference']['number'] or '',
                'warnings':' | '.join(x['quality_warnings']),
                'publication_state':'draft','operational_place_id':''})
    stats={'total_records':len(cands),
      'map_numbered_records':sum(x['map_reference']['number'] is not None for x in cands),
      'additional_records':sum(x['map_reference']['number'] is None for x in cands),
      'municipality_pending':sum(x['municipality']['name'] is None for x in cands),
      'geo_verified':sum(x['geolocation']['verified'] for x in cands),
      'photos_license_claim_candidates':sum(any(m['provider']=='wikimedia_commons' for m in x['media_candidates']) for x in cands),
      'official_gallery_candidates':sum(any(m['provider']=='institutional_gallery' for m in x['media_candidates']) for x in cands),
      'operationally_importable':sum(x['operational_link']['operational_approved'] for x in cands),
      'publication_approved':sum(x['publication']['state']=='published' for x in cands),
      'warning_counts':dict(collections.Counter(y for x in cands for y in x['quality_warnings'])),
      'source_sha256':obj['source_sha256'],
      'backend_writes':0}
    (ROOT/'reports/preflight.json').write_text(json.dumps(stats,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
    print(json.dumps(stats,ensure_ascii=False,indent=2))

if __name__=='__main__':main()
